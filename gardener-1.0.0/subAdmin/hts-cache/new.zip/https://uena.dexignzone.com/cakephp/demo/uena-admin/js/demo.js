<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">    <title>
        Error    </title>
    <link href="/cakephp/demo/favicon.ico" type="image/x-icon" rel="icon"><link href="/cakephp/demo/favicon.ico" type="image/x-icon" rel="shortcut icon">
    
	<link rel="stylesheet" href="/cakephp/demo/normalize.min.css">
	<link rel="stylesheet" href="/cakephp/demo/milligram.min.css">
	<link rel="stylesheet" href="/cakephp/demo/fonts.css">
	<link rel="stylesheet" href="/cakephp/demo/cake.css">

            </head>
<body>
    <div class="error-container">
                <h2>Not Found</h2>
<p class="error">
    <strong>Error: </strong>
    The requested address <strong>'/uena-admin/js/demo.js'</strong> was not found on this server.</p>
        <a href="javascript:history.back()">Back</a>    </div>
</body>
</html>
